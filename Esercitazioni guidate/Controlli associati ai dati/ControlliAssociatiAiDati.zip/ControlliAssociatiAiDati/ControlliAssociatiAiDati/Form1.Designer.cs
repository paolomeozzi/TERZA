﻿namespace ControlliAssociatiAiDati
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lstGeneri = new System.Windows.Forms.ListBox();
            this.lblGenere = new System.Windows.Forms.Label();
            this.btnVisualizza = new System.Windows.Forms.Button();
            this.cmbGeneri = new System.Windows.Forms.ComboBox();
            this.dvPiloti = new System.Windows.Forms.DataGridView();
            this.Cognome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Moto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnVisualizzaPilota = new System.Windows.Forms.Button();
            this.lblPilota = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dvPiloti)).BeginInit();
            this.SuspendLayout();
            // 
            // lstGeneri
            // 
            this.lstGeneri.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstGeneri.FormattingEnabled = true;
            this.lstGeneri.ItemHeight = 25;
            this.lstGeneri.Location = new System.Drawing.Point(12, 12);
            this.lstGeneri.Name = "lstGeneri";
            this.lstGeneri.Size = new System.Drawing.Size(234, 204);
            this.lstGeneri.TabIndex = 0;
            this.lstGeneri.SelectedIndexChanged += new System.EventHandler(this.lstGeneri_SelectedIndexChanged);
            // 
            // lblGenere
            // 
            this.lblGenere.AutoSize = true;
            this.lblGenere.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenere.Location = new System.Drawing.Point(336, 12);
            this.lblGenere.Name = "lblGenere";
            this.lblGenere.Size = new System.Drawing.Size(54, 25);
            this.lblGenere.TabIndex = 1;
            this.lblGenere.Text = "N.D.";
            // 
            // btnVisualizza
            // 
            this.btnVisualizza.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualizza.Location = new System.Drawing.Point(12, 222);
            this.btnVisualizza.Name = "btnVisualizza";
            this.btnVisualizza.Size = new System.Drawing.Size(234, 37);
            this.btnVisualizza.TabIndex = 2;
            this.btnVisualizza.Text = "Visualizza";
            this.btnVisualizza.UseVisualStyleBackColor = true;
            this.btnVisualizza.Click += new System.EventHandler(this.btnVisualizza_Click);
            // 
            // cmbGeneri
            // 
            this.cmbGeneri.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGeneri.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGeneri.FormattingEnabled = true;
            this.cmbGeneri.Location = new System.Drawing.Point(271, 70);
            this.cmbGeneri.Name = "cmbGeneri";
            this.cmbGeneri.Size = new System.Drawing.Size(198, 33);
            this.cmbGeneri.TabIndex = 3;
            // 
            // dvPiloti
            // 
            this.dvPiloti.AllowUserToAddRows = false;
            this.dvPiloti.AllowUserToDeleteRows = false;
            this.dvPiloti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvPiloti.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cognome,
            this.Nome,
            this.Moto,
            this.Numero});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.RosyBrown;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dvPiloti.DefaultCellStyle = dataGridViewCellStyle1;
            this.dvPiloti.Location = new System.Drawing.Point(271, 145);
            this.dvPiloti.Name = "dvPiloti";
            this.dvPiloti.ReadOnly = true;
            this.dvPiloti.RowTemplate.Height = 45;
            this.dvPiloti.Size = new System.Drawing.Size(540, 172);
            this.dvPiloti.TabIndex = 4;
            // 
            // Cognome
            // 
            this.Cognome.HeaderText = "Cognome";
            this.Cognome.Name = "Cognome";
            this.Cognome.ReadOnly = true;
            // 
            // Nome
            // 
            this.Nome.HeaderText = "Nome";
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            // 
            // Moto
            // 
            this.Moto.HeaderText = "Moto";
            this.Moto.Name = "Moto";
            this.Moto.ReadOnly = true;
            // 
            // Numero
            // 
            this.Numero.HeaderText = "Numero";
            this.Numero.Name = "Numero";
            this.Numero.ReadOnly = true;
            this.Numero.Width = 50;
            // 
            // btnVisualizzaPilota
            // 
            this.btnVisualizzaPilota.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualizzaPilota.Location = new System.Drawing.Point(271, 339);
            this.btnVisualizzaPilota.Name = "btnVisualizzaPilota";
            this.btnVisualizzaPilota.Size = new System.Drawing.Size(234, 37);
            this.btnVisualizzaPilota.TabIndex = 5;
            this.btnVisualizzaPilota.Text = "Visualizza";
            this.btnVisualizzaPilota.UseVisualStyleBackColor = true;
            this.btnVisualizzaPilota.Click += new System.EventHandler(this.btnVisualizzaPilota_Click);
            // 
            // lblPilota
            // 
            this.lblPilota.AutoSize = true;
            this.lblPilota.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPilota.Location = new System.Drawing.Point(277, 407);
            this.lblPilota.Name = "lblPilota";
            this.lblPilota.Size = new System.Drawing.Size(54, 25);
            this.lblPilota.TabIndex = 6;
            this.lblPilota.Text = "N.D.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 517);
            this.Controls.Add(this.lblPilota);
            this.Controls.Add(this.btnVisualizzaPilota);
            this.Controls.Add(this.dvPiloti);
            this.Controls.Add(this.cmbGeneri);
            this.Controls.Add(this.btnVisualizza);
            this.Controls.Add(this.lblGenere);
            this.Controls.Add(this.lstGeneri);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvPiloti)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstGeneri;
        private System.Windows.Forms.Label lblGenere;
        private System.Windows.Forms.Button btnVisualizza;
        private System.Windows.Forms.ComboBox cmbGeneri;
        private System.Windows.Forms.DataGridView dvPiloti;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cognome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Moto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numero;
        private System.Windows.Forms.Button btnVisualizzaPilota;
        private System.Windows.Forms.Label lblPilota;
    }
}

