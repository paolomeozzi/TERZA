﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlliAssociatiAiDati
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] generi = { "Fisica", "Matematica", "Filosofia" };
        private void Form1_Load(object sender, EventArgs e)
        {
            CreaPiloti();

            VisualizzaPiloti();
            //lboGeneri.DataSource = generi;
            lstGeneri.Items.Clear();
            lstGeneri.Items.AddRange(generi);
            //foreach (var genere in generi)
            //{
            //    lboGeneri.Items.Add(genere);
            //}
            cmbGeneri.Items.AddRange(generi);
        }

        void VisualizzaPiloti()
        {
            dvPiloti.Rows.Clear();
            foreach (Pilota p in piloti)
            {
                dvPiloti.Rows.Add(p.Cognome, p.Nome, p.Moto, p.Numero);
            }
        }


        #region GENERAZIONE DATI PILOTI
        List<Pilota> piloti;
        void CreaPiloti()
        {
            piloti = new List<Pilota>();
            piloti.Add(new Pilota { Nome = "Maverick", Cognome = "Vinales", Punti = 50, Vittorie = 2, Moto = "Yamaha", Numero = 25 });
            piloti.Add(new Pilota { Nome = "Valentino", Cognome = "Rossi", Punti = 36, Vittorie = 0, Moto = "Yamaha", Numero = 46 });
            piloti.Add(new Pilota { Nome = "Andrea", Cognome = "Dovizioso", Punti = 20, Vittorie = 0, Moto = "Ducati", Numero = 4 });
            piloti.Add(new Pilota { Nome = "Jorge", Cognome = "Lorenzo", Punti = 5, Vittorie = 0, Moto = "Ducati", Numero = 99 });
            piloti.Add(new Pilota { Nome = "Dani", Cognome = "Pedrosa", Punti = 11, Vittorie = 0, Moto = "Honda", Numero = 26 });
            piloti.Add(new Pilota { Nome = "Marc", Cognome = "Marquez", Punti = 13, Vittorie = 0, Moto = "Honda", Numero = 93 });
            piloti.Add(new Pilota { Nome = "Alex", Cognome = "Espargaro", Punti = 10, Vittorie = 0, Moto = "Aprilia", Numero = 41 });
        }
        #endregion

        private void btnVisualizza_Click(object sender, EventArgs e)
        {
            if (cmbGeneri.SelectedIndex == -1)
                return;
            //lblGenere.Text = generi[lstGeneri.SelectedIndex];
            
            lblGenere.Text = cmbGeneri.Text;
        }

        private void lstGeneri_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstGeneri.SelectedIndex == -1)
                return;

            lblGenere.Text = lstGeneri.Text;
        }

        private void btnVisualizzaPilota_Click(object sender, EventArgs e)
        {
            if (dvPiloti.SelectedRows.Count == 0)
                return;
            int indPilota = dvPiloti.SelectedRows[0].Index;
            Pilota p = piloti[indPilota];
            lblPilota.Text = $"{p.Cognome}, {p.Nome}  {p.Moto}";

        }
    }
}
