﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ControlliAssociatiAiDati
{
    public class Pilota
    {
        public string Nome;
        public string Cognome;
        public string Moto;
        public int Numero;
        public int Punti;
        public int Vittorie;
        
    }
}
