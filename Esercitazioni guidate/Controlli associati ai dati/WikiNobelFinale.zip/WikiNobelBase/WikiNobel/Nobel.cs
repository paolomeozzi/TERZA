﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WikiNobel
{
    class Nobel
    {
        public string Cognome;
        public string Nome;
        public string Categoria;
        public DateTime DataNascita;
        public string Foto;
    }
}
