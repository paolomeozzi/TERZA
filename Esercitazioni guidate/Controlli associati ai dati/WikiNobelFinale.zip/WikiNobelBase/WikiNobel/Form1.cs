﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WikiNobel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    

        const string TutteLeCategorie = "[TUTTE]";  // tutte le categorie

        List<Nobel> vincitori;
        string[] categorie = { TutteLeCategorie, "Fisica", "Chimica", "Medicina" };
        private void Form1_Load(object sender, EventArgs e)
        {
            vincitori = GestioneNobel.CaricaVincitori();
            //cmbCategorie.Items.AddRange(categorie);
            //cmbCategorie.SelectedIndex = 0;
            cmbCategorie.DataSource = categorie;
            VisualizzaVincitori();
        }

        void VisualizzaVincitori()
        {
            dvNobel.Rows.Clear();
            foreach (Nobel vi in vincitori)
            {
                if (vi.Categoria == cmbCategorie.Text || cmbCategorie.Text == TutteLeCategorie)
                {
                    int indice = dvNobel.Rows.Add(vi.Cognome, vi.Nome, vi.Categoria);
                    DataGridViewRow dr = dvNobel.Rows[indice];
                    dr.Tag = vi;
                }
            }
        }


        private void dvNobel_SelectionChanged(object sender, EventArgs e)
        {
            if (dvNobel.SelectedRows.Count == 0)
            {
                VisualizzaVincitore(null);
            }
            else
            {
                DataGridViewRow dr = dvNobel.SelectedRows[0];
                Nobel vi = (Nobel)dr.Tag;

                VisualizzaVincitore(vi);
            }
        }

        void VisualizzaVincitore(Nobel vi)
        {
            if (vi != null)
            {
                picFoto.Image = Image.FromFile("Foto/" + vi.Foto);
                lblVincitore.Text = $"{vi.Cognome}, {vi.Nome}";
            }
            else
            {
                picFoto.Image = null;
                lblVincitore.Text = "";
            }
        }

        private void cmbDiscipline_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCategorie.SelectedIndex == -1)
                return;
            VisualizzaVincitori();
        }

        

        

        List<Nobel> CreaListaVincitori()
        {
            var lista = new List<Nobel>();
            lista.Add(new Nobel
            {
                Cognome = "Einstein",
                Nome = "Albert",
                Categoria = "Fisica",
                DataNascita = new DateTime(1879, 3, 14),
                Foto = "EinsteinAlbert.jpg"

            });
            lista.Add(new Nobel
            {
                Cognome = "Fermi",
                Nome = "Enrico",
                Categoria = "Fisica",
                DataNascita = new DateTime(1901, 9, 29),
                Foto = "FermiEnrico.jpg"
            });
            lista.Add(new Nobel
            {
                Cognome = "Feynman",
                Nome = "Richard",
                Categoria = "Fisica",
                DataNascita = new DateTime(1918, 5, 11),
                Foto = "FeynmanRichard.jpg"
            });
            lista.Add(new Nobel
            {
                Cognome = "Curie",
                Nome = "Irene",
                Categoria = "Chimica",
                DataNascita = new DateTime(1897, 9, 12),
                Foto = "CurieIrene.jpg"
            });
            lista.Add(new Nobel
            {
                Cognome = "Pauling",
                Nome = "Linus",
                Categoria = "Chimica",
                DataNascita = new DateTime(1901, 2, 28),
                Foto = "PaulingLinus.jpg"
            });

            lista.Add(new Nobel
            {
                Cognome = "Montagnier",
                Nome = "Luc",
                Categoria = "Medicina",
                DataNascita = new DateTime(1932, 8, 18),
                Foto = "MontagnierLuc.jpg"
            });

            lista.Add(new Nobel
            {
                Cognome = "Fleming",
                Nome = "Alexander",
                Categoria = "Medicina",
                DataNascita = new DateTime(1881, 8, 6),
                Foto = "FlemingAlexander.jpg"
            });

            return lista;
        }
    }
}
