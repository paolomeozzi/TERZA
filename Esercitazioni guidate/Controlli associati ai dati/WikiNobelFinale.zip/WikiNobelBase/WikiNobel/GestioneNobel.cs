﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WikiNobel
{
    static class GestioneNobel
    {
        const string FILE_VINCITORI = "Vincitori.txt";

        // #COGNOME; NOME;CATEGORIA;DATA NASCITA; FOTO
        public static List<Nobel> CaricaVincitori()
        {
            List<Nobel> ris = new List<Nobel>();
            string[] righe = File.ReadAllLines(FILE_VINCITORI);
            foreach (string riga in righe)
            {
                if (riga.Trim() == "" || riga.Trim().StartsWith("#"))
                    continue;

                string[] campi = riga.Split(';');
                Nobel nobel = new Nobel
                {
                    Cognome = campi[0].Trim(),
                    Nome = campi[1].Trim(),
                    Categoria = campi[2].Trim(),
                    DataNascita = DateTime.Parse(campi[3]),
                    Foto = campi[4].Trim()
                };
                ris.Add(nobel);
            }
            return ris;
        }
    }
}
