﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WikiScienza
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<VincitoreNobel> vincitori;
        string[] categorie = { "Fisica", "Chimica", "Medicina" };

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbCategorie.Items.AddRange(categorie);
            vincitori = GeneraListaVincitori();
            VisualizzaVincitori();
            
        }

        void VisualizzaVincitoriPerCategoria(string categoria)
        {
            dvNobel.Rows.Clear();
            foreach (VincitoreNobel nobel in vincitori)
            {
                if (nobel.Categoria == categoria)
                {
                    dvNobel.Rows.Add(nobel.Cognome, nobel.Nome, nobel.DataNascita);
                }
            }
        }

        void VisualizzaVincitori()
        {
            dvNobel.Rows.Clear();
            foreach (VincitoreNobel nobel in vincitori)
            {
                dvNobel.Rows.Add(nobel.Cognome, nobel.Nome, nobel.DataNascita);
            }
        }

        
        List<VincitoreNobel> GeneraListaVincitori()
        {
            var lista = new List<VincitoreNobel>();

            lista.Add(new VincitoreNobel
            {
                Cognome = "Einstein",
                Nome = "Alfred",
                Categoria = "Fisica",
                DataNascita = new DateTime(1879, 3, 14),
                Foto = "EinsteinAlbert.jpg"
            });

            lista.Add(new VincitoreNobel
            {
                Cognome = "Pauling",
                Nome = "Linus",
                Categoria = "Chimica",
                DataNascita = new DateTime(1901, 2, 28),
                Foto = "PaulingLinus.jpg"
            });

            lista.Add(new VincitoreNobel
            {
                Cognome = "Fermi",
                Nome = "Enrico",
                Categoria = "Fisica",
                DataNascita = new DateTime(1901, 9, 29),
                Foto = "FermiEnrico.jpg"
            });
            lista.Add(new VincitoreNobel
            {
                Cognome = "Feynman",
                Nome = "Richard",
                Categoria = "Fisica",
                DataNascita = new DateTime(1918, 5, 11),
                Foto = "FeynmanRichard.jpg"
            });
            lista.Add(new VincitoreNobel
            {
                Cognome = "Curie",
                Nome = "Irene",
                Categoria = "Chimica",
                DataNascita = new DateTime(1897, 9, 12),
                Foto = "CurieIrene.jpg"
            });

            lista.Add(new VincitoreNobel
            {
                Cognome = "Montagnier",
                Nome = "Luc",
                Categoria = "Medicina",
                DataNascita = new DateTime(1932, 8, 18),
                Foto = "MontagnierLuc.jpg"
            });

            lista.Add(new VincitoreNobel
            {
                Cognome = "Fleming",
                Nome = "Alexander",
                Categoria = "Medicina",
                DataNascita = new DateTime(1881, 8, 6),
                Foto = "FlemingAlexander.jpg"
            });

            return lista;
        }

        private void btnVisualizzaVincitore_Click(object sender, EventArgs e)
        {
            if (dvNobel.SelectedRows.Count == 0)
                return;
            int indNobel = dvNobel.SelectedRows[0].Index;
            VincitoreNobel nobel = vincitori[indNobel];
            picFoto.Image = Image.FromFile("Foto/" + nobel.Foto);

            lblNobel.Text = $"{nobel.Cognome}, {nobel.Nome}";
        }

        private void cmbCategorie_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCategorie.SelectedIndex == -1)
                return;
            //string categoria = categorie[cmbCategorie.SelectedIndex];
            VisualizzaVincitoriPerCategoria(cmbCategorie.Text);
        }

        private void dvNobel_SelectionChanged(object sender, EventArgs e)
        {
            if (dvNobel.SelectedRows.Count == 0)
                return;
            int indNobel = dvNobel.SelectedRows[0].Index;
            VincitoreNobel nobel = vincitori[indNobel];
            picFoto.Image = Image.FromFile("Foto/" + nobel.Foto);

            lblNobel.Text = $"{nobel.Cognome}, {nobel.Nome}";
        }
    }
}
