﻿namespace WikiScienza
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmbCategorie = new System.Windows.Forms.ComboBox();
            this.dvNobel = new System.Windows.Forms.DataGridView();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.Cognome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnVisualizzaVincitore = new System.Windows.Forms.Button();
            this.lblNobel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dvNobel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbCategorie
            // 
            this.cmbCategorie.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategorie.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCategorie.FormattingEnabled = true;
            this.cmbCategorie.Location = new System.Drawing.Point(21, 41);
            this.cmbCategorie.Name = "cmbCategorie";
            this.cmbCategorie.Size = new System.Drawing.Size(183, 33);
            this.cmbCategorie.TabIndex = 0;
            this.cmbCategorie.SelectedIndexChanged += new System.EventHandler(this.cmbCategorie_SelectedIndexChanged);
            // 
            // dvNobel
            // 
            this.dvNobel.AllowUserToAddRows = false;
            this.dvNobel.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dvNobel.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dvNobel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvNobel.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cognome,
            this.Nome,
            this.Data});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dvNobel.DefaultCellStyle = dataGridViewCellStyle3;
            this.dvNobel.Location = new System.Drawing.Point(248, 41);
            this.dvNobel.Name = "dvNobel";
            this.dvNobel.ReadOnly = true;
            this.dvNobel.RowTemplate.Height = 32;
            this.dvNobel.Size = new System.Drawing.Size(500, 356);
            this.dvNobel.TabIndex = 1;
            this.dvNobel.SelectionChanged += new System.EventHandler(this.dvNobel_SelectionChanged);
            // 
            // picFoto
            // 
            this.picFoto.Location = new System.Drawing.Point(21, 111);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(183, 209);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFoto.TabIndex = 2;
            this.picFoto.TabStop = false;
            // 
            // Cognome
            // 
            this.Cognome.HeaderText = "Cognome";
            this.Cognome.Name = "Cognome";
            this.Cognome.ReadOnly = true;
            this.Cognome.Width = 150;
            // 
            // Nome
            // 
            this.Nome.HeaderText = "Nome";
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            this.Nome.Width = 150;
            // 
            // Data
            // 
            dataGridViewCellStyle2.Format = "d";
            this.Data.DefaultCellStyle = dataGridViewCellStyle2;
            this.Data.HeaderText = "Data";
            this.Data.Name = "Data";
            this.Data.ReadOnly = true;
            this.Data.Width = 130;
            // 
            // btnVisualizzaVincitore
            // 
            this.btnVisualizzaVincitore.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualizzaVincitore.Location = new System.Drawing.Point(248, 422);
            this.btnVisualizzaVincitore.Name = "btnVisualizzaVincitore";
            this.btnVisualizzaVincitore.Size = new System.Drawing.Size(266, 49);
            this.btnVisualizzaVincitore.TabIndex = 3;
            this.btnVisualizzaVincitore.Text = "Visualizza foto vincitore";
            this.btnVisualizzaVincitore.UseVisualStyleBackColor = true;
            this.btnVisualizzaVincitore.Click += new System.EventHandler(this.btnVisualizzaVincitore_Click);
            // 
            // lblNobel
            // 
            this.lblNobel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNobel.Location = new System.Drawing.Point(21, 338);
            this.lblNobel.Name = "lblNobel";
            this.lblNobel.Size = new System.Drawing.Size(183, 70);
            this.lblNobel.TabIndex = 4;
            this.lblNobel.Text = "N.D.";
            this.lblNobel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 483);
            this.Controls.Add(this.lblNobel);
            this.Controls.Add(this.btnVisualizzaVincitore);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.dvNobel);
            this.Controls.Add(this.cmbCategorie);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvNobel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCategorie;
        private System.Windows.Forms.DataGridView dvNobel;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cognome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.Button btnVisualizzaVincitore;
        private System.Windows.Forms.Label lblNobel;
    }
}

